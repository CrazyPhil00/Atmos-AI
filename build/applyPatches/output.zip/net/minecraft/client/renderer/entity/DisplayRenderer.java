package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Transformation;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.Display;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@OnlyIn(Dist.CLIENT)
public abstract class DisplayRenderer<T extends Display> extends EntityRenderer<T> {
   private static final float f_268590_ = 64.0F;
   private final EntityRenderDispatcher f_268749_;

   protected DisplayRenderer(EntityRendererProvider.Context p_270168_) {
      super(p_270168_);
      this.f_268749_ = p_270168_.m_174022_();
   }

   public ResourceLocation m_5478_(T p_270675_) {
      return TextureAtlas.f_118259_;
   }

   public void m_7392_(T p_270405_, float p_270225_, float p_270279_, PoseStack p_270728_, MultiBufferSource p_270209_, int p_270298_) {
      float f = p_270405_.m_272147_(p_270279_);
      this.f_114477_ = Math.min(p_270405_.m_269510_(f), 64.0F);
      this.f_114478_ = p_270405_.m_269072_(f);
      int i = p_270405_.m_269041_();
      int j = i != -1 ? i : p_270298_;
      super.m_7392_(p_270405_, p_270225_, p_270279_, p_270728_, p_270209_, j);
      p_270728_.m_85836_();
      p_270728_.m_252781_(this.m_269592_(p_270405_));
      Transformation transformation = p_270405_.m_269158_(f);
      p_270728_.m_252931_(transformation.m_252783_());
      p_270728_.m_85850_().m_252943_().rotate(transformation.m_253244_()).rotate(transformation.m_252848_());
      this.m_269019_(p_270405_, p_270728_, p_270209_, j, f);
      p_270728_.m_85849_();
   }

   private Quaternionf m_269592_(T p_271013_) {
      Camera camera = this.f_268749_.f_114358_;
      Quaternionf quaternionf;
      switch (p_271013_.m_269218_()) {
         case FIXED:
            quaternionf = p_271013_.m_269190_();
            break;
         case HORIZONTAL:
            quaternionf = (new Quaternionf()).rotationYXZ(-0.017453292F * p_271013_.m_146908_(), -0.017453292F * camera.m_90589_(), 0.0F);
            break;
         case VERTICAL:
            quaternionf = (new Quaternionf()).rotationYXZ((float)Math.PI - ((float)Math.PI / 180F) * camera.m_90590_(), ((float)Math.PI / 180F) * p_271013_.m_146909_(), 0.0F);
            break;
         case CENTER:
            quaternionf = (new Quaternionf()).rotationYXZ((float)Math.PI - ((float)Math.PI / 180F) * camera.m_90590_(), -0.017453292F * camera.m_90589_(), 0.0F);
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return quaternionf;
   }

   protected abstract void m_269019_(T p_270246_, PoseStack p_270944_, MultiBufferSource p_270706_, int p_270263_, float p_270377_);

   @OnlyIn(Dist.CLIENT)
   public static class BlockDisplayRenderer extends DisplayRenderer<Display.BlockDisplay> {
      private final BlockRenderDispatcher f_268487_;

      protected BlockDisplayRenderer(EntityRendererProvider.Context p_270283_) {
         super(p_270283_);
         this.f_268487_ = p_270283_.m_234597_();
      }

      public void m_269019_(Display.BlockDisplay p_270998_, PoseStack p_270530_, MultiBufferSource p_270995_, int p_270553_, float p_270920_) {
         this.f_268487_.m_110912_(p_270998_.m_269134_(), p_270530_, p_270995_, p_270553_, OverlayTexture.f_118083_);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class ItemDisplayRenderer extends DisplayRenderer<Display.ItemDisplay> {
      private final ItemRenderer f_268604_;

      protected ItemDisplayRenderer(EntityRendererProvider.Context p_270110_) {
         super(p_270110_);
         this.f_268604_ = p_270110_.m_174025_();
      }

      public void m_269019_(Display.ItemDisplay p_270490_, PoseStack p_270693_, MultiBufferSource p_271002_, int p_270588_, float p_270590_) {
         this.f_268604_.m_269128_(p_270490_.m_269568_(), p_270490_.m_269386_(), p_270588_, OverlayTexture.f_118083_, p_270693_, p_271002_, p_270490_.m_9236_(), p_270490_.m_19879_());
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class TextDisplayRenderer extends DisplayRenderer<Display.TextDisplay> {
      private final Font f_268575_;

      protected TextDisplayRenderer(EntityRendererProvider.Context p_271012_) {
         super(p_271012_);
         this.f_268575_ = p_271012_.m_174028_();
      }

      private Display.TextDisplay.CachedInfo m_269268_(Component p_270823_, int p_270893_) {
         List<FormattedCharSequence> list = this.f_268575_.m_92923_(p_270823_, p_270893_);
         List<Display.TextDisplay.CachedLine> list1 = new ArrayList<>(list.size());
         int i = 0;

         for(FormattedCharSequence formattedcharsequence : list) {
            int j = this.f_268575_.m_92724_(formattedcharsequence);
            i = Math.max(i, j);
            list1.add(new Display.TextDisplay.CachedLine(formattedcharsequence, j));
         }

         return new Display.TextDisplay.CachedInfo(list1, i);
      }

      public void m_269019_(Display.TextDisplay p_270749_, PoseStack p_270232_, MultiBufferSource p_270522_, int p_270936_, float p_270759_) {
         byte b0 = p_270749_.m_269327_();
         boolean flag = (b0 & 2) != 0;
         boolean flag1 = (b0 & 4) != 0;
         boolean flag2 = (b0 & 1) != 0;
         Display.TextDisplay.Align display$textdisplay$align = Display.TextDisplay.m_269384_(b0);
         byte b1 = p_270749_.m_269004_(p_270759_);
         int i;
         if (flag1) {
            float f = Minecraft.m_91087_().f_91066_.m_92141_(0.25F);
            i = (int)(f * 255.0F) << 24;
         } else {
            i = p_270749_.m_269173_(p_270759_);
         }

         float f2 = 0.0F;
         Matrix4f matrix4f = p_270232_.m_85850_().m_252922_();
         matrix4f.rotate((float)Math.PI, 0.0F, 1.0F, 0.0F);
         matrix4f.scale(-0.025F, -0.025F, -0.025F);
         Display.TextDisplay.CachedInfo display$textdisplay$cachedinfo = p_270749_.m_269343_(this::m_269268_);
         int j = 9 + 1;
         int k = display$textdisplay$cachedinfo.f_268557_();
         int l = display$textdisplay$cachedinfo.f_268675_().size() * j;
         matrix4f.translate(1.0F - (float)k / 2.0F, (float)(-l), 0.0F);
         if (i != 0) {
            VertexConsumer vertexconsumer = p_270522_.m_6299_(flag ? RenderType.m_269508_() : RenderType.m_269058_());
            vertexconsumer.m_252986_(matrix4f, -1.0F, -1.0F, 0.0F).m_193479_(i).m_85969_(p_270936_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, -1.0F, (float)l, 0.0F).m_193479_(i).m_85969_(p_270936_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, (float)k, (float)l, 0.0F).m_193479_(i).m_85969_(p_270936_).m_5752_();
            vertexconsumer.m_252986_(matrix4f, (float)k, -1.0F, 0.0F).m_193479_(i).m_85969_(p_270936_).m_5752_();
         }

         for(Display.TextDisplay.CachedLine display$textdisplay$cachedline : display$textdisplay$cachedinfo.f_268675_()) {
            float f3;
            switch (display$textdisplay$align) {
               case LEFT:
                  f3 = 0.0F;
                  break;
               case RIGHT:
                  f3 = (float)(k - display$textdisplay$cachedline.f_268443_());
                  break;
               case CENTER:
                  f3 = (float)k / 2.0F - (float)display$textdisplay$cachedline.f_268443_() / 2.0F;
                  break;
               default:
                  throw new IncompatibleClassChangeError();
            }

            float f1 = f3;
            this.f_268575_.m_272191_(display$textdisplay$cachedline.f_268516_(), f1, f2, b1 << 24 | 16777215, flag2, matrix4f, p_270522_, flag ? Font.DisplayMode.SEE_THROUGH : Font.DisplayMode.POLYGON_OFFSET, 0, p_270936_);
            f2 += (float)j;
         }

      }
   }
}