package net.minecraft.client.renderer.entity;

import com.google.common.collect.Sets;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.SheetedDecalTextureGenerator;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexMultiConsumer;
import com.mojang.math.MatrixUtil;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.ItemModelShaper;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.StainedGlassPaneBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class ItemRenderer implements ResourceManagerReloadListener {
   public static final ResourceLocation f_273897_ = new ResourceLocation("textures/misc/enchanted_glint_entity.png");
   public static final ResourceLocation f_273833_ = new ResourceLocation("textures/misc/enchanted_glint_item.png");
   private static final Set<Item> f_115094_ = Sets.newHashSet(Items.f_41852_);
   private static final int f_174221_ = 8;
   private static final int f_174222_ = 8;
   public static final int f_174218_ = 200;
   public static final float f_174219_ = 0.5F;
   public static final float f_174220_ = 0.75F;
   public static final float f_256734_ = 0.0078125F;
   private static final ModelResourceLocation f_244324_ = ModelResourceLocation.m_245263_("trident", "inventory");
   public static final ModelResourceLocation f_244055_ = ModelResourceLocation.m_245263_("trident_in_hand", "inventory");
   private static final ModelResourceLocation f_244537_ = ModelResourceLocation.m_245263_("spyglass", "inventory");
   public static final ModelResourceLocation f_243706_ = ModelResourceLocation.m_245263_("spyglass_in_hand", "inventory");
   private final Minecraft f_265848_;
   private final ItemModelShaper f_115095_;
   private final TextureManager f_115096_;
   private final ItemColors f_115097_;
   private final BlockEntityWithoutLevelRenderer f_174223_;

   public ItemRenderer(Minecraft p_266926_, TextureManager p_266774_, ModelManager p_266850_, ItemColors p_267016_, BlockEntityWithoutLevelRenderer p_267049_) {
      this.f_265848_ = p_266926_;
      this.f_115096_ = p_266774_;
      this.f_115095_ = new ItemModelShaper(p_266850_);
      this.f_174223_ = p_267049_;

      for(Item item : BuiltInRegistries.f_257033_) {
         if (!f_115094_.contains(item)) {
            this.f_115095_.m_109396_(item, new ModelResourceLocation(BuiltInRegistries.f_257033_.m_7981_(item), "inventory"));
         }
      }

      this.f_115097_ = p_267016_;
   }

   public ItemModelShaper m_115103_() {
      return this.f_115095_;
   }

   private void m_115189_(BakedModel p_115190_, ItemStack p_115191_, int p_115192_, int p_115193_, PoseStack p_115194_, VertexConsumer p_115195_) {
      RandomSource randomsource = RandomSource.m_216327_();
      long i = 42L;

      for(Direction direction : Direction.values()) {
         randomsource.m_188584_(42L);
         this.m_115162_(p_115194_, p_115195_, p_115190_.m_213637_((BlockState)null, direction, randomsource), p_115191_, p_115192_, p_115193_);
      }

      randomsource.m_188584_(42L);
      this.m_115162_(p_115194_, p_115195_, p_115190_.m_213637_((BlockState)null, (Direction)null, randomsource), p_115191_, p_115192_, p_115193_);
   }

   public void m_115143_(ItemStack p_115144_, ItemDisplayContext p_270188_, boolean p_115146_, PoseStack p_115147_, MultiBufferSource p_115148_, int p_115149_, int p_115150_, BakedModel p_115151_) {
      if (!p_115144_.m_41619_()) {
         p_115147_.m_85836_();
         boolean flag = p_270188_ == ItemDisplayContext.GUI || p_270188_ == ItemDisplayContext.GROUND || p_270188_ == ItemDisplayContext.FIXED;
         if (flag) {
            if (p_115144_.m_150930_(Items.f_42713_)) {
               p_115151_ = this.f_115095_.m_109393_().m_119422_(f_244324_);
            } else if (p_115144_.m_150930_(Items.f_151059_)) {
               p_115151_ = this.f_115095_.m_109393_().m_119422_(f_244537_);
            }
         }

         p_115151_.m_7442_().m_269404_(p_270188_).m_111763_(p_115146_, p_115147_);
         p_115147_.m_252880_(-0.5F, -0.5F, -0.5F);
         if (!p_115151_.m_7521_() && (!p_115144_.m_150930_(Items.f_42713_) || flag)) {
            boolean flag1;
            if (p_270188_ != ItemDisplayContext.GUI && !p_270188_.m_269069_() && p_115144_.m_41720_() instanceof BlockItem) {
               Block block = ((BlockItem)p_115144_.m_41720_()).m_40614_();
               flag1 = !(block instanceof HalfTransparentBlock) && !(block instanceof StainedGlassPaneBlock);
            } else {
               flag1 = true;
            }

            RenderType rendertype = ItemBlockRenderTypes.m_109279_(p_115144_, flag1);
            VertexConsumer vertexconsumer;
            if (p_115144_.m_204117_(ItemTags.f_215866_) && p_115144_.m_41790_()) {
               p_115147_.m_85836_();
               PoseStack.Pose posestack$pose = p_115147_.m_85850_();
               if (p_270188_ == ItemDisplayContext.GUI) {
                  MatrixUtil.m_253023_(posestack$pose.m_252922_(), 0.5F);
               } else if (p_270188_.m_269069_()) {
                  MatrixUtil.m_253023_(posestack$pose.m_252922_(), 0.75F);
               }

               if (flag1) {
                  vertexconsumer = m_115207_(p_115148_, rendertype, posestack$pose);
               } else {
                  vertexconsumer = m_115180_(p_115148_, rendertype, posestack$pose);
               }

               p_115147_.m_85849_();
            } else if (flag1) {
               vertexconsumer = m_115222_(p_115148_, rendertype, true, p_115144_.m_41790_());
            } else {
               vertexconsumer = m_115211_(p_115148_, rendertype, true, p_115144_.m_41790_());
            }

            this.m_115189_(p_115151_, p_115144_, p_115149_, p_115150_, p_115147_, vertexconsumer);
         } else {
            this.f_174223_.m_108829_(p_115144_, p_270188_, p_115147_, p_115148_, p_115149_, p_115150_);
         }

         p_115147_.m_85849_();
      }
   }

   public static VertexConsumer m_115184_(MultiBufferSource p_115185_, RenderType p_115186_, boolean p_115187_, boolean p_115188_) {
      return p_115188_ ? VertexMultiConsumer.m_86168_(p_115185_.m_6299_(p_115187_ ? RenderType.m_110481_() : RenderType.m_110484_()), p_115185_.m_6299_(p_115186_)) : p_115185_.m_6299_(p_115186_);
   }

   public static VertexConsumer m_115180_(MultiBufferSource p_115181_, RenderType p_115182_, PoseStack.Pose p_115183_) {
      return VertexMultiConsumer.m_86168_(new SheetedDecalTextureGenerator(p_115181_.m_6299_(RenderType.m_110490_()), p_115183_.m_252922_(), p_115183_.m_252943_(), 0.0078125F), p_115181_.m_6299_(p_115182_));
   }

   public static VertexConsumer m_115207_(MultiBufferSource p_115208_, RenderType p_115209_, PoseStack.Pose p_115210_) {
      return VertexMultiConsumer.m_86168_(new SheetedDecalTextureGenerator(p_115208_.m_6299_(RenderType.m_110493_()), p_115210_.m_252922_(), p_115210_.m_252943_(), 0.0078125F), p_115208_.m_6299_(p_115209_));
   }

   public static VertexConsumer m_115211_(MultiBufferSource p_115212_, RenderType p_115213_, boolean p_115214_, boolean p_115215_) {
      if (p_115215_) {
         return Minecraft.m_91085_() && p_115213_ == Sheets.m_110791_() ? VertexMultiConsumer.m_86168_(p_115212_.m_6299_(RenderType.m_110487_()), p_115212_.m_6299_(p_115213_)) : VertexMultiConsumer.m_86168_(p_115212_.m_6299_(p_115214_ ? RenderType.m_110490_() : RenderType.m_110496_()), p_115212_.m_6299_(p_115213_));
      } else {
         return p_115212_.m_6299_(p_115213_);
      }
   }

   public static VertexConsumer m_115222_(MultiBufferSource p_115223_, RenderType p_115224_, boolean p_115225_, boolean p_115226_) {
      return p_115226_ ? VertexMultiConsumer.m_86168_(p_115223_.m_6299_(p_115225_ ? RenderType.m_110493_() : RenderType.m_110499_()), p_115223_.m_6299_(p_115224_)) : p_115223_.m_6299_(p_115224_);
   }

   private void m_115162_(PoseStack p_115163_, VertexConsumer p_115164_, List<BakedQuad> p_115165_, ItemStack p_115166_, int p_115167_, int p_115168_) {
      boolean flag = !p_115166_.m_41619_();
      PoseStack.Pose posestack$pose = p_115163_.m_85850_();

      for(BakedQuad bakedquad : p_115165_) {
         int i = -1;
         if (flag && bakedquad.m_111304_()) {
            i = this.f_115097_.m_92676_(p_115166_, bakedquad.m_111305_());
         }

         float f = (float)(i >> 16 & 255) / 255.0F;
         float f1 = (float)(i >> 8 & 255) / 255.0F;
         float f2 = (float)(i & 255) / 255.0F;
         p_115164_.m_85987_(posestack$pose, bakedquad, f, f1, f2, p_115167_, p_115168_);
      }

   }

   public BakedModel m_174264_(ItemStack p_174265_, @Nullable Level p_174266_, @Nullable LivingEntity p_174267_, int p_174268_) {
      BakedModel bakedmodel;
      if (p_174265_.m_150930_(Items.f_42713_)) {
         bakedmodel = this.f_115095_.m_109393_().m_119422_(f_244055_);
      } else if (p_174265_.m_150930_(Items.f_151059_)) {
         bakedmodel = this.f_115095_.m_109393_().m_119422_(f_243706_);
      } else {
         bakedmodel = this.f_115095_.m_109406_(p_174265_);
      }

      ClientLevel clientlevel = p_174266_ instanceof ClientLevel ? (ClientLevel)p_174266_ : null;
      BakedModel bakedmodel1 = bakedmodel.m_7343_().m_173464_(bakedmodel, p_174265_, clientlevel, p_174267_, p_174268_);
      return bakedmodel1 == null ? this.f_115095_.m_109393_().m_119409_() : bakedmodel1;
   }

   public void m_269128_(ItemStack p_270761_, ItemDisplayContext p_270648_, int p_270410_, int p_270894_, PoseStack p_270430_, MultiBufferSource p_270457_, @Nullable Level p_270149_, int p_270509_) {
      this.m_269491_((LivingEntity)null, p_270761_, p_270648_, false, p_270430_, p_270457_, p_270149_, p_270410_, p_270894_, p_270509_);
   }

   public void m_269491_(@Nullable LivingEntity p_270101_, ItemStack p_270637_, ItemDisplayContext p_270437_, boolean p_270434_, PoseStack p_270230_, MultiBufferSource p_270411_, @Nullable Level p_270641_, int p_270595_, int p_270927_, int p_270845_) {
      if (!p_270637_.m_41619_()) {
         BakedModel bakedmodel = this.m_174264_(p_270637_, p_270641_, p_270101_, p_270845_);
         this.m_115143_(p_270637_, p_270437_, p_270434_, p_270230_, p_270411_, p_270595_, p_270927_, bakedmodel);
      }
   }

   public void m_274569_(PoseStack p_275410_, ItemStack p_275575_, int p_275265_, int p_275235_) {
      this.m_274490_(p_275410_, p_275575_, p_275265_, p_275235_, this.m_174264_(p_275575_, (Level)null, (LivingEntity)null, 0));
   }

   protected void m_274490_(PoseStack p_275246_, ItemStack p_275195_, int p_275214_, int p_275658_, BakedModel p_275740_) {
      p_275246_.m_85836_();
      p_275246_.m_252880_((float)p_275214_, (float)p_275658_, 100.0F);
      p_275246_.m_252880_(8.0F, 8.0F, 0.0F);
      p_275246_.m_252931_((new Matrix4f()).scaling(1.0F, -1.0F, 1.0F));
      p_275246_.m_85841_(16.0F, 16.0F, 16.0F);
      MultiBufferSource.BufferSource multibuffersource$buffersource = this.f_265848_.m_91269_().m_110104_();
      boolean flag = !p_275740_.m_7547_();
      if (flag) {
         Lighting.m_84930_();
      }

      PoseStack posestack = RenderSystem.m_157191_();
      posestack.m_85836_();
      posestack.m_252931_(p_275246_.m_85850_().m_252922_());
      RenderSystem.m_157182_();
      this.m_115143_(p_275195_, ItemDisplayContext.GUI, false, new PoseStack(), multibuffersource$buffersource, 15728880, OverlayTexture.f_118083_, p_275740_);
      multibuffersource$buffersource.m_109911_();
      RenderSystem.m_69482_();
      if (flag) {
         Lighting.m_84931_();
      }

      p_275246_.m_85849_();
      posestack.m_85849_();
      RenderSystem.m_157182_();
   }

   public void m_274369_(PoseStack p_275197_, ItemStack p_275552_, int p_275198_, int p_275738_) {
      this.m_274303_(p_275197_, this.f_265848_.f_91074_, this.f_265848_.f_91073_, p_275552_, p_275198_, p_275738_, 0);
   }

   public void m_274407_(PoseStack p_275539_, ItemStack p_275685_, int p_275360_, int p_275448_, int p_275456_) {
      this.m_274303_(p_275539_, this.f_265848_.f_91074_, this.f_265848_.f_91073_, p_275685_, p_275360_, p_275448_, p_275456_);
   }

   public void m_274350_(PoseStack p_275305_, ItemStack p_275612_, int p_275743_, int p_275591_, int p_275231_, int p_275345_) {
      this.m_274616_(p_275305_, this.f_265848_.f_91074_, this.f_265848_.f_91073_, p_275612_, p_275743_, p_275591_, p_275231_, p_275345_);
   }

   public void m_274336_(PoseStack p_275285_, ItemStack p_275595_, int p_275671_, int p_275526_) {
      this.m_274303_(p_275285_, (LivingEntity)null, this.f_265848_.f_91073_, p_275595_, p_275671_, p_275526_, 0);
   }

   public void m_274301_(PoseStack p_275668_, LivingEntity p_275691_, ItemStack p_275472_, int p_275283_, int p_275239_, int p_275587_) {
      this.m_274303_(p_275668_, p_275691_, p_275691_.f_19853_, p_275472_, p_275283_, p_275239_, p_275587_);
   }

   private void m_274303_(PoseStack p_275571_, @Nullable LivingEntity p_275317_, @Nullable Level p_275599_, ItemStack p_275500_, int p_275679_, int p_275377_, int p_275380_) {
      this.m_274616_(p_275571_, p_275317_, p_275599_, p_275500_, p_275679_, p_275377_, p_275380_, 0);
   }

   private void m_274616_(PoseStack p_275419_, @Nullable LivingEntity p_275405_, @Nullable Level p_275402_, ItemStack p_275431_, int p_275347_, int p_275504_, int p_275678_, int p_275555_) {
      if (!p_275431_.m_41619_()) {
         BakedModel bakedmodel = this.m_174264_(p_275431_, p_275402_, p_275405_, p_275678_);
         p_275419_.m_85836_();
         p_275419_.m_252880_(0.0F, 0.0F, (float)(50 + (bakedmodel.m_7539_() ? p_275555_ : 0)));

         try {
            this.m_274490_(p_275419_, p_275431_, p_275347_, p_275504_, bakedmodel);
         } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.m_127521_(throwable, "Rendering item");
            CrashReportCategory crashreportcategory = crashreport.m_127514_("Item being rendered");
            crashreportcategory.m_128165_("Item Type", () -> {
               return String.valueOf((Object)p_275431_.m_41720_());
            });
            crashreportcategory.m_128165_("Item Damage", () -> {
               return String.valueOf(p_275431_.m_41773_());
            });
            crashreportcategory.m_128165_("Item NBT", () -> {
               return String.valueOf((Object)p_275431_.m_41783_());
            });
            crashreportcategory.m_128165_("Item Foil", () -> {
               return String.valueOf(p_275431_.m_41790_());
            });
            throw new ReportedException(crashreport);
         }

         p_275419_.m_85849_();
      }
   }

   public void m_274412_(PoseStack p_275553_, Font p_275636_, ItemStack p_275514_, int p_275695_, int p_275460_) {
      this.m_274364_(p_275553_, p_275636_, p_275514_, p_275695_, p_275460_, (String)null);
   }

   public void m_274364_(PoseStack p_275269_, Font p_275652_, ItemStack p_275590_, int p_275202_, int p_275508_, @Nullable String p_275302_) {
      if (!p_275590_.m_41619_()) {
         p_275269_.m_85836_();
         if (p_275590_.m_41613_() != 1 || p_275302_ != null) {
            String s = p_275302_ == null ? String.valueOf(p_275590_.m_41613_()) : p_275302_;
            p_275269_.m_252880_(0.0F, 0.0F, 200.0F);
            MultiBufferSource.BufferSource multibuffersource$buffersource = MultiBufferSource.m_109898_(Tesselator.m_85913_().m_85915_());
            p_275652_.m_271703_(s, (float)(p_275202_ + 19 - 2 - p_275652_.m_92895_(s)), (float)(p_275508_ + 6 + 3), 16777215, true, p_275269_.m_85850_().m_252922_(), multibuffersource$buffersource, Font.DisplayMode.NORMAL, 0, 15728880);
            multibuffersource$buffersource.m_109911_();
         }

         if (p_275590_.m_150947_()) {
            RenderSystem.m_69465_();
            int k = p_275590_.m_150948_();
            int l = p_275590_.m_150949_();
            int i = p_275202_ + 2;
            int j = p_275508_ + 13;
            GuiComponent.m_93172_(p_275269_, i, j, i + 13, j + 2, -16777216);
            GuiComponent.m_93172_(p_275269_, i, j, i + k, j + 1, l | -16777216);
            RenderSystem.m_69482_();
         }

         LocalPlayer localplayer = this.f_265848_.f_91074_;
         float f = localplayer == null ? 0.0F : localplayer.m_36335_().m_41521_(p_275590_.m_41720_(), this.f_265848_.m_91296_());
         if (f > 0.0F) {
            RenderSystem.m_69465_();
            int i1 = p_275508_ + Mth.m_14143_(16.0F * (1.0F - f));
            int j1 = i1 + Mth.m_14167_(16.0F * f);
            GuiComponent.m_93172_(p_275269_, p_275202_, i1, p_275202_ + 16, j1, Integer.MAX_VALUE);
            RenderSystem.m_69482_();
         }

         p_275269_.m_85849_();
      }
   }

   public void m_6213_(ResourceManager p_115105_) {
      this.f_115095_.m_109403_();
   }
}