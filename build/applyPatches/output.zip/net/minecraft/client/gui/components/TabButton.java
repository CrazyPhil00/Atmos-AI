package net.minecraft.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.tabs.Tab;
import net.minecraft.client.gui.components.tabs.TabManager;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TabButton extends AbstractWidget {
   private static final ResourceLocation f_273920_ = new ResourceLocation("textures/gui/tab_button.png");
   private static final int f_273933_ = 130;
   private static final int f_273828_ = 24;
   private static final int f_273883_ = 2;
   private static final int f_273822_ = 0;
   private static final int f_273861_ = 3;
   private static final int f_273873_ = 1;
   private static final int f_273895_ = 1;
   private static final int f_273921_ = 4;
   private static final int f_273844_ = 2;
   private final TabManager f_273884_;
   private final Tab f_273837_;

   public TabButton(TabManager p_275399_, Tab p_275391_, int p_275340_, int p_275364_) {
      super(0, 0, p_275340_, p_275364_, p_275391_.m_267600_());
      this.f_273884_ = p_275399_;
      this.f_273837_ = p_275391_;
   }

   public void m_87963_(PoseStack p_275359_, int p_275220_, int p_275351_, float p_275440_) {
      RenderSystem.m_157456_(0, f_273920_);
      m_267814_(p_275359_, this.m_252754_(), this.m_252907_(), this.f_93618_, this.f_93619_, 2, 2, 2, 0, 130, 24, 0, this.m_274514_());
      Font font = Minecraft.m_91087_().f_91062_;
      int i = this.f_93623_ ? -1 : -6250336;
      this.m_274488_(p_275359_, font, i);
      if (this.m_274319_()) {
         this.m_274365_(p_275359_, font, i);
      }

   }

   public void m_274488_(PoseStack p_275321_, Font p_275208_, int p_275293_) {
      int i = this.m_252754_() + 1;
      int j = this.m_252907_() + (this.m_274319_() ? 0 : 3);
      int k = this.m_252754_() + this.m_5711_() - 1;
      int l = this.m_252907_() + this.m_93694_();
      m_274366_(p_275321_, p_275208_, this.m_6035_(), i, j, k, l, p_275293_);
   }

   private void m_274365_(PoseStack p_275458_, Font p_275475_, int p_275367_) {
      int i = Math.min(p_275475_.m_92852_(this.m_6035_()), this.m_5711_() - 4);
      int j = this.m_252754_() + (this.m_5711_() - i) / 2;
      int k = this.m_252907_() + this.m_93694_() - 2;
      m_93172_(p_275458_, j, k, j + i, k + 1, p_275367_);
   }

   protected int m_274514_() {
      int i = 2;
      if (this.m_274319_() && this.m_198029_()) {
         i = 1;
      } else if (this.m_274319_()) {
         i = 0;
      } else if (this.m_198029_()) {
         i = 3;
      }

      return i * 24;
   }

   protected void m_168797_(NarrationElementOutput p_275465_) {
      p_275465_.m_169146_(NarratedElementType.TITLE, Component.m_237110_("gui.narrate.tab", this.f_273837_.m_267600_()));
   }

   public void m_7435_(SoundManager p_276302_) {
   }

   public Tab m_274356_() {
      return this.f_273837_;
   }

   public boolean m_274319_() {
      return this.f_273884_.m_267695_() == this.f_273837_;
   }
}