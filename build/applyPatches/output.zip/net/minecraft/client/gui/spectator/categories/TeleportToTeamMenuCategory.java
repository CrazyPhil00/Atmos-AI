package net.minecraft.client.gui.spectator.categories;

import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.gui.components.spectator.SpectatorGui;
import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.client.gui.spectator.SpectatorMenuCategory;
import net.minecraft.client.gui.spectator.SpectatorMenuItem;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TeleportToTeamMenuCategory implements SpectatorMenuCategory, SpectatorMenuItem {
   private static final Component f_101875_ = Component.m_237115_("spectatorMenu.team_teleport");
   private static final Component f_101876_ = Component.m_237115_("spectatorMenu.team_teleport.prompt");
   private final List<SpectatorMenuItem> f_101877_;

   public TeleportToTeamMenuCategory() {
      Minecraft minecraft = Minecraft.m_91087_();
      this.f_101877_ = m_257833_(minecraft, minecraft.f_91073_.m_6188_());
   }

   private static List<SpectatorMenuItem> m_257833_(Minecraft p_260258_, Scoreboard p_259249_) {
      return p_259249_.m_83491_().stream().flatMap((p_260025_) -> {
         return TeleportToTeamMenuCategory.TeamSelectionItem.m_257760_(p_260258_, p_260025_).stream();
      }).toList();
   }

   public List<SpectatorMenuItem> m_5919_() {
      return this.f_101877_;
   }

   public Component m_5878_() {
      return f_101876_;
   }

   public void m_7608_(SpectatorMenu p_101886_) {
      p_101886_.m_101794_(this);
   }

   public Component m_7869_() {
      return f_101875_;
   }

   public void m_6252_(PoseStack p_101882_, float p_101883_, int p_101884_) {
      RenderSystem.m_157456_(0, SpectatorGui.f_94760_);
      GuiComponent.m_93133_(p_101882_, 0, 0, 16.0F, 0.0F, 16, 16, 256, 256);
   }

   public boolean m_7304_() {
      return !this.f_101877_.isEmpty();
   }

   @OnlyIn(Dist.CLIENT)
   static class TeamSelectionItem implements SpectatorMenuItem {
      private final PlayerTeam f_101891_;
      private final ResourceLocation f_256959_;
      private final List<PlayerInfo> f_101893_;

      private TeamSelectionItem(PlayerTeam p_259176_, List<PlayerInfo> p_259231_, ResourceLocation p_260113_) {
         this.f_101891_ = p_259176_;
         this.f_101893_ = p_259231_;
         this.f_256959_ = p_260113_;
      }

      public static Optional<SpectatorMenuItem> m_257760_(Minecraft p_260048_, PlayerTeam p_259058_) {
         List<PlayerInfo> list = new ArrayList<>();

         for(String s : p_259058_.m_6809_()) {
            PlayerInfo playerinfo = p_260048_.m_91403_().m_104938_(s);
            if (playerinfo != null && playerinfo.m_105325_() != GameType.SPECTATOR) {
               list.add(playerinfo);
            }
         }

         if (list.isEmpty()) {
            return Optional.empty();
         } else {
            GameProfile gameprofile = list.get(RandomSource.m_216327_().m_188503_(list.size())).m_105312_();
            ResourceLocation resourcelocation = p_260048_.m_91109_().m_240306_(gameprofile);
            return Optional.of(new TeleportToTeamMenuCategory.TeamSelectionItem(p_259058_, list, resourcelocation));
         }
      }

      public void m_7608_(SpectatorMenu p_101902_) {
         p_101902_.m_101794_(new TeleportToPlayerMenuCategory(this.f_101893_));
      }

      public Component m_7869_() {
         return this.f_101891_.m_83364_();
      }

      public void m_6252_(PoseStack p_101898_, float p_101899_, int p_101900_) {
         Integer integer = this.f_101891_.m_7414_().m_126665_();
         if (integer != null) {
            float f = (float)(integer >> 16 & 255) / 255.0F;
            float f1 = (float)(integer >> 8 & 255) / 255.0F;
            float f2 = (float)(integer & 255) / 255.0F;
            GuiComponent.m_93172_(p_101898_, 1, 1, 15, 15, Mth.m_14159_(f * p_101899_, f1 * p_101899_, f2 * p_101899_) | p_101900_ << 24);
         }

         RenderSystem.m_157456_(0, this.f_256959_);
         RenderSystem.m_157429_(p_101899_, p_101899_, p_101899_, (float)p_101900_ / 255.0F);
         PlayerFaceRenderer.m_240071_(p_101898_, 2, 2, 12);
         RenderSystem.m_157429_(1.0F, 1.0F, 1.0F, 1.0F);
      }

      public boolean m_7304_() {
         return true;
      }
   }
}