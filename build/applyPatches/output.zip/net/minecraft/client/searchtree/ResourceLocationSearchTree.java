package net.minecraft.client.searchtree;

import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ResourceLocationSearchTree<T> {
   static <T> ResourceLocationSearchTree<T> m_235205_() {
      return new ResourceLocationSearchTree<T>() {
         public List<T> m_213904_(String p_235218_) {
            return List.of();
         }

         public List<T> m_213906_(String p_235220_) {
            return List.of();
         }
      };
   }

   static <T> ResourceLocationSearchTree<T> m_235212_(List<T> p_235213_, Function<T, Stream<ResourceLocation>> p_235214_) {
      if (p_235213_.isEmpty()) {
         return m_235205_();
      } else {
         final SuffixArray<T> suffixarray = new SuffixArray<>();
         final SuffixArray<T> suffixarray1 = new SuffixArray<>();

         for(T t : p_235213_) {
            p_235214_.apply(t).forEach((p_235210_) -> {
               suffixarray.m_119970_(t, p_235210_.m_135827_().toLowerCase(Locale.ROOT));
               suffixarray1.m_119970_(t, p_235210_.m_135815_().toLowerCase(Locale.ROOT));
            });
         }

         suffixarray.m_119967_();
         suffixarray1.m_119967_();
         return new ResourceLocationSearchTree<T>() {
            public List<T> m_213904_(String p_235227_) {
               return suffixarray.m_119973_(p_235227_);
            }

            public List<T> m_213906_(String p_235229_) {
               return suffixarray1.m_119973_(p_235229_);
            }
         };
      }
   }

   List<T> m_213904_(String p_235211_);

   List<T> m_213906_(String p_235215_);
}