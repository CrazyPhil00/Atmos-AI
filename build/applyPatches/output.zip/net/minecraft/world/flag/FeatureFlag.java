package net.minecraft.world.flag;

public class FeatureFlag {
   final FeatureFlagUniverse f_243952_;
   final long f_244012_;

   FeatureFlag(FeatureFlagUniverse p_249115_, int p_251067_) {
      this.f_243952_ = p_249115_;
      this.f_244012_ = 1L << p_251067_;
   }
}