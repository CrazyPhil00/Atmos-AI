package net.minecraft.world.damagesource;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record DamageType(String f_268677_, DamageScaling f_268501_, float f_268663_, DamageEffects f_268686_, DeathMessageType f_268472_) {
   public static final Codec<DamageType> f_268510_ = RecordCodecBuilder.create((p_270460_) -> {
      return p_270460_.group(Codec.STRING.fieldOf("message_id").forGetter(DamageType::f_268677_), DamageScaling.f_268563_.fieldOf("scaling").forGetter(DamageType::f_268501_), Codec.FLOAT.fieldOf("exhaustion").forGetter(DamageType::f_268663_), DamageEffects.f_268463_.optionalFieldOf("effects", DamageEffects.HURT).forGetter(DamageType::f_268686_), DeathMessageType.f_268483_.optionalFieldOf("death_message_type", DeathMessageType.DEFAULT).forGetter(DamageType::f_268472_)).apply(p_270460_, DamageType::new);
   });

   public DamageType(String p_270099_, DamageScaling p_270717_, float p_270846_) {
      this(p_270099_, p_270717_, p_270846_, DamageEffects.HURT, DeathMessageType.DEFAULT);
   }

   public DamageType(String p_270743_, DamageScaling p_270585_, float p_270555_, DamageEffects p_270608_) {
      this(p_270743_, p_270585_, p_270555_, p_270608_, DeathMessageType.DEFAULT);
   }

   public DamageType(String p_270473_, float p_270700_, DamageEffects p_270105_) {
      this(p_270473_, DamageScaling.WHEN_CAUSED_BY_LIVING_NON_PLAYER, p_270700_, p_270105_);
   }

   public DamageType(String p_270454_, float p_270889_) {
      this(p_270454_, DamageScaling.WHEN_CAUSED_BY_LIVING_NON_PLAYER, p_270889_);
   }
}