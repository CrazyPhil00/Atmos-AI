package net.minecraft.world.item.crafting;

import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public abstract class AbstractCookingRecipe implements Recipe<Container> {
   protected final RecipeType<?> f_43726_;
   protected final ResourceLocation f_43727_;
   private final CookingBookCategory f_243702_;
   protected final String f_43728_;
   protected final Ingredient f_43729_;
   protected final ItemStack f_43730_;
   protected final float f_43731_;
   protected final int f_43732_;

   public AbstractCookingRecipe(RecipeType<?> p_250197_, ResourceLocation p_249379_, String p_249518_, CookingBookCategory p_250891_, Ingredient p_251354_, ItemStack p_252185_, float p_252165_, int p_250256_) {
      this.f_43726_ = p_250197_;
      this.f_243702_ = p_250891_;
      this.f_43727_ = p_249379_;
      this.f_43728_ = p_249518_;
      this.f_43729_ = p_251354_;
      this.f_43730_ = p_252185_;
      this.f_43731_ = p_252165_;
      this.f_43732_ = p_250256_;
   }

   public boolean m_5818_(Container p_43748_, Level p_43749_) {
      return this.f_43729_.test(p_43748_.m_8020_(0));
   }

   public ItemStack m_5874_(Container p_43746_, RegistryAccess p_267063_) {
      return this.f_43730_.m_41777_();
   }

   public boolean m_8004_(int p_43743_, int p_43744_) {
      return true;
   }

   public NonNullList<Ingredient> m_7527_() {
      NonNullList<Ingredient> nonnulllist = NonNullList.m_122779_();
      nonnulllist.add(this.f_43729_);
      return nonnulllist;
   }

   public float m_43750_() {
      return this.f_43731_;
   }

   public ItemStack m_8043_(RegistryAccess p_266851_) {
      return this.f_43730_;
   }

   public String m_6076_() {
      return this.f_43728_;
   }

   public int m_43753_() {
      return this.f_43732_;
   }

   public ResourceLocation m_6423_() {
      return this.f_43727_;
   }

   public RecipeType<?> m_6671_() {
      return this.f_43726_;
   }

   public CookingBookCategory m_245534_() {
      return this.f_243702_;
   }
}