package net.minecraft.world.item.enchantment;

import java.util.Map;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;

public class ThornsEnchantment extends Enchantment {
   private static final float f_151302_ = 0.15F;

   public ThornsEnchantment(Enchantment.Rarity p_45196_, EquipmentSlot... p_45197_) {
      super(p_45196_, EnchantmentCategory.ARMOR_CHEST, p_45197_);
   }

   public int m_6183_(int p_45200_) {
      return 10 + 20 * (p_45200_ - 1);
   }

   public int m_6175_(int p_45210_) {
      return super.m_6183_(p_45210_) + 50;
   }

   public int m_6586_() {
      return 3;
   }

   public boolean m_6081_(ItemStack p_45205_) {
      return p_45205_.m_41720_() instanceof ArmorItem ? true : super.m_6081_(p_45205_);
   }

   public void m_7675_(LivingEntity p_45215_, Entity p_45216_, int p_45217_) {
      RandomSource randomsource = p_45215_.m_217043_();
      Map.Entry<EquipmentSlot, ItemStack> entry = EnchantmentHelper.m_44906_(Enchantments.f_44972_, p_45215_);
      if (m_220316_(p_45217_, randomsource)) {
         if (p_45216_ != null) {
            p_45216_.m_6469_(p_45215_.m_269291_().m_269374_(p_45215_), (float)m_220319_(p_45217_, randomsource));
         }

         if (entry != null) {
            entry.getValue().m_41622_(2, p_45215_, (p_45208_) -> {
               p_45208_.m_21166_(entry.getKey());
            });
         }
      }

   }

   public static boolean m_220316_(int p_220317_, RandomSource p_220318_) {
      if (p_220317_ <= 0) {
         return false;
      } else {
         return p_220318_.m_188501_() < 0.15F * (float)p_220317_;
      }
   }

   public static int m_220319_(int p_220320_, RandomSource p_220321_) {
      return p_220320_ > 10 ? p_220320_ - 10 : 1 + p_220321_.m_188503_(4);
   }
}