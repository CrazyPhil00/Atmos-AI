package net.minecraft.world.level.chunk;

import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;

public interface StructureAccess {
   @Nullable
   StructureStart m_213652_(Structure p_223434_);

   void m_213792_(Structure p_223437_, StructureStart p_223438_);

   LongSet m_213649_(Structure p_223439_);

   void m_213843_(Structure p_223435_, long p_223436_);

   Map<Structure, LongSet> m_62769_();

   void m_62737_(Map<Structure, LongSet> p_223440_);
}