package net.minecraft.world.level.levelgen.placement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;

public class SurfaceRelativeThresholdFilter extends PlacementFilter {
   public static final Codec<SurfaceRelativeThresholdFilter> f_191919_ = RecordCodecBuilder.create((p_191929_) -> {
      return p_191929_.group(Heightmap.Types.f_64274_.fieldOf("heightmap").forGetter((p_191944_) -> {
         return p_191944_.f_191920_;
      }), Codec.INT.optionalFieldOf("min_inclusive", Integer.valueOf(Integer.MIN_VALUE)).forGetter((p_191942_) -> {
         return p_191942_.f_191921_;
      }), Codec.INT.optionalFieldOf("max_inclusive", Integer.valueOf(Integer.MAX_VALUE)).forGetter((p_191939_) -> {
         return p_191939_.f_191922_;
      })).apply(p_191929_, SurfaceRelativeThresholdFilter::new);
   });
   private final Heightmap.Types f_191920_;
   private final int f_191921_;
   private final int f_191922_;

   private SurfaceRelativeThresholdFilter(Heightmap.Types p_191925_, int p_191926_, int p_191927_) {
      this.f_191920_ = p_191925_;
      this.f_191921_ = p_191926_;
      this.f_191922_ = p_191927_;
   }

   public static SurfaceRelativeThresholdFilter m_191930_(Heightmap.Types p_191931_, int p_191932_, int p_191933_) {
      return new SurfaceRelativeThresholdFilter(p_191931_, p_191932_, p_191933_);
   }

   protected boolean m_213917_(PlacementContext p_226407_, RandomSource p_226408_, BlockPos p_226409_) {
      long i = (long)p_226407_.m_191824_(this.f_191920_, p_226409_.m_123341_(), p_226409_.m_123343_());
      long j = i + (long)this.f_191921_;
      long k = i + (long)this.f_191922_;
      return j <= (long)p_226409_.m_123342_() && (long)p_226409_.m_123342_() <= k;
   }

   public PlacementModifierType<?> m_183327_() {
      return PlacementModifierType.f_191850_;
   }
}