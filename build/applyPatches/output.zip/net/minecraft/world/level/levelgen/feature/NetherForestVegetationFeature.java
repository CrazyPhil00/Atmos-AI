package net.minecraft.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.configurations.NetherForestVegetationConfig;

public class NetherForestVegetationFeature extends Feature<NetherForestVegetationConfig> {
   public NetherForestVegetationFeature(Codec<NetherForestVegetationConfig> p_66361_) {
      super(p_66361_);
   }

   public boolean m_142674_(FeaturePlaceContext<NetherForestVegetationConfig> p_160068_) {
      WorldGenLevel worldgenlevel = p_160068_.m_159774_();
      BlockPos blockpos = p_160068_.m_159777_();
      BlockState blockstate = worldgenlevel.m_8055_(blockpos.m_7495_());
      NetherForestVegetationConfig netherforestvegetationconfig = p_160068_.m_159778_();
      RandomSource randomsource = p_160068_.m_225041_();
      if (!blockstate.m_204336_(BlockTags.f_13077_)) {
         return false;
      } else {
         int i = blockpos.m_123342_();
         if (i >= worldgenlevel.m_141937_() + 1 && i + 1 < worldgenlevel.m_151558_()) {
            int j = 0;

            for(int k = 0; k < netherforestvegetationconfig.f_191259_ * netherforestvegetationconfig.f_191259_; ++k) {
               BlockPos blockpos1 = blockpos.m_7918_(randomsource.m_188503_(netherforestvegetationconfig.f_191259_) - randomsource.m_188503_(netherforestvegetationconfig.f_191259_), randomsource.m_188503_(netherforestvegetationconfig.f_191260_) - randomsource.m_188503_(netherforestvegetationconfig.f_191260_), randomsource.m_188503_(netherforestvegetationconfig.f_191259_) - randomsource.m_188503_(netherforestvegetationconfig.f_191259_));
               BlockState blockstate1 = netherforestvegetationconfig.f_67540_.m_213972_(randomsource, blockpos1);
               if (worldgenlevel.m_46859_(blockpos1) && blockpos1.m_123342_() > worldgenlevel.m_141937_() && blockstate1.m_60710_(worldgenlevel, blockpos1)) {
                  worldgenlevel.m_7731_(blockpos1, blockstate1, 2);
                  ++j;
               }
            }

            return j > 0;
         } else {
            return false;
         }
      }
   }
}