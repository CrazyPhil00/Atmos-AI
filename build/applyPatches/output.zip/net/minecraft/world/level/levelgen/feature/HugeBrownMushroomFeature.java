package net.minecraft.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.HugeMushroomBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.configurations.HugeMushroomFeatureConfiguration;

public class HugeBrownMushroomFeature extends AbstractHugeMushroomFeature {
   public HugeBrownMushroomFeature(Codec<HugeMushroomFeatureConfiguration> p_65879_) {
      super(p_65879_);
   }

   protected void m_213950_(LevelAccessor p_225043_, RandomSource p_225044_, BlockPos p_225045_, int p_225046_, BlockPos.MutableBlockPos p_225047_, HugeMushroomFeatureConfiguration p_225048_) {
      int i = p_225048_.f_67742_;

      for(int j = -i; j <= i; ++j) {
         for(int k = -i; k <= i; ++k) {
            boolean flag = j == -i;
            boolean flag1 = j == i;
            boolean flag2 = k == -i;
            boolean flag3 = k == i;
            boolean flag4 = flag || flag1;
            boolean flag5 = flag2 || flag3;
            if (!flag4 || !flag5) {
               p_225047_.m_122154_(p_225045_, j, p_225046_, k);
               if (!p_225043_.m_8055_(p_225047_).m_60804_(p_225043_, p_225047_)) {
                  boolean flag6 = flag || flag5 && j == 1 - i;
                  boolean flag7 = flag1 || flag5 && j == i - 1;
                  boolean flag8 = flag2 || flag4 && k == 1 - i;
                  boolean flag9 = flag3 || flag4 && k == i - 1;
                  BlockState blockstate = p_225048_.f_67740_.m_213972_(p_225044_, p_225045_);
                  if (blockstate.m_61138_(HugeMushroomBlock.f_54130_) && blockstate.m_61138_(HugeMushroomBlock.f_54128_) && blockstate.m_61138_(HugeMushroomBlock.f_54127_) && blockstate.m_61138_(HugeMushroomBlock.f_54129_)) {
                     blockstate = blockstate.m_61124_(HugeMushroomBlock.f_54130_, Boolean.valueOf(flag6)).m_61124_(HugeMushroomBlock.f_54128_, Boolean.valueOf(flag7)).m_61124_(HugeMushroomBlock.f_54127_, Boolean.valueOf(flag8)).m_61124_(HugeMushroomBlock.f_54129_, Boolean.valueOf(flag9));
                  }

                  this.m_5974_(p_225043_, p_225047_, blockstate);
               }
            }
         }
      }

   }

   protected int m_6794_(int p_65881_, int p_65882_, int p_65883_, int p_65884_) {
      return p_65884_ <= 3 ? 0 : p_65883_;
   }
}