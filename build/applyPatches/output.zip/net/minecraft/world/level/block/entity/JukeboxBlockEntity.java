package net.minecraft.world.level.block.entity;

import com.google.common.annotations.VisibleForTesting;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.Clearable;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.RecordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.ticks.ContainerSingleItem;

public class JukeboxBlockEntity extends BlockEntity implements Clearable, ContainerSingleItem {
   private static final int f_271500_ = 20;
   private final NonNullList<ItemStack> f_271436_ = NonNullList.m_122780_(this.m_6643_(), ItemStack.f_41583_);
   private int f_238796_;
   private long f_238695_;
   private long f_238572_;
   private boolean f_238637_;

   public JukeboxBlockEntity(BlockPos p_155613_, BlockState p_155614_) {
      super(BlockEntityType.f_58921_, p_155613_, p_155614_);
   }

   public void m_142466_(CompoundTag p_155616_) {
      super.m_142466_(p_155616_);
      if (p_155616_.m_128425_("RecordItem", 10)) {
         this.f_271436_.set(0, ItemStack.m_41712_(p_155616_.m_128469_("RecordItem")));
      }

      this.f_238637_ = p_155616_.m_128471_("IsPlaying");
      this.f_238572_ = p_155616_.m_128454_("RecordStartTick");
      this.f_238695_ = p_155616_.m_128454_("TickCount");
   }

   protected void m_183515_(CompoundTag p_187507_) {
      super.m_183515_(p_187507_);
      if (!this.m_272036_().m_41619_()) {
         p_187507_.m_128365_("RecordItem", this.m_272036_().m_41739_(new CompoundTag()));
      }

      p_187507_.m_128379_("IsPlaying", this.f_238637_);
      p_187507_.m_128356_("RecordStartTick", this.f_238572_);
      p_187507_.m_128356_("TickCount", this.f_238695_);
   }

   public boolean m_272025_() {
      return !this.m_272036_().m_41619_() && this.f_238637_;
   }

   private void m_271871_(@Nullable Entity p_273308_, boolean p_273038_) {
      if (this.f_58857_.m_8055_(this.m_58899_()) == this.m_58900_()) {
         this.f_58857_.m_7731_(this.m_58899_(), this.m_58900_().m_61124_(JukeboxBlock.f_54254_, Boolean.valueOf(p_273038_)), 2);
         this.f_58857_.m_220407_(GameEvent.f_157792_, this.m_58899_(), GameEvent.Context.m_223719_(p_273308_, this.m_58900_()));
      }

   }

   @VisibleForTesting
   public void m_271687_() {
      this.f_238572_ = this.f_238695_;
      this.f_238637_ = true;
      this.f_58857_.m_46672_(this.m_58899_(), this.m_58900_().m_60734_());
      this.f_58857_.m_5898_((Player)null, 1010, this.m_58899_(), Item.m_41393_(this.m_272036_().m_41720_()));
      this.m_6596_();
   }

   private void m_272088_() {
      this.f_238637_ = false;
      this.f_58857_.m_220407_(GameEvent.f_238649_, this.m_58899_(), GameEvent.Context.m_223722_(this.m_58900_()));
      this.f_58857_.m_46672_(this.m_58899_(), this.m_58900_().m_60734_());
      this.f_58857_.m_46796_(1011, this.m_58899_(), 0);
      this.m_6596_();
   }

   private void m_272276_(Level p_273615_, BlockPos p_273143_, BlockState p_273372_) {
      ++this.f_238796_;
      if (this.m_272025_()) {
         Item item = this.m_272036_().m_41720_();
         if (item instanceof RecordItem) {
            RecordItem recorditem = (RecordItem)item;
            if (this.m_271713_(recorditem)) {
               this.m_272088_();
            } else if (this.m_239365_()) {
               this.f_238796_ = 0;
               p_273615_.m_220407_(GameEvent.f_238690_, p_273143_, GameEvent.Context.m_223722_(p_273372_));
               this.m_269320_(p_273615_, p_273143_);
            }
         }
      }

      ++this.f_238695_;
   }

   private boolean m_271713_(RecordItem p_273267_) {
      return this.f_238695_ >= this.f_238572_ + (long)p_273267_.m_43036_() + 20L;
   }

   private boolean m_239365_() {
      return this.f_238796_ >= 20;
   }

   public ItemStack m_8020_(int p_273280_) {
      return this.f_271436_.get(p_273280_);
   }

   public ItemStack m_7407_(int p_273514_, int p_273414_) {
      ItemStack itemstack = Objects.requireNonNullElse(this.f_271436_.get(p_273514_), ItemStack.f_41583_);
      this.f_271436_.set(p_273514_, ItemStack.f_41583_);
      if (!itemstack.m_41619_()) {
         this.m_271871_((Entity)null, false);
         this.m_272088_();
      }

      return itemstack;
   }

   public void m_6836_(int p_273461_, ItemStack p_273584_) {
      if (p_273584_.m_204117_(ItemTags.f_13158_) && this.f_58857_ != null) {
         this.f_271436_.set(p_273461_, p_273584_);
         this.m_271871_((Entity)null, true);
         this.m_271687_();
      }

   }

   public int m_6893_() {
      return 1;
   }

   public boolean m_6542_(Player p_273466_) {
      return Container.m_272074_(this, p_273466_);
   }

   public boolean m_7013_(int p_273369_, ItemStack p_273689_) {
      return p_273689_.m_204117_(ItemTags.f_13158_) && this.m_8020_(p_273369_).m_41619_();
   }

   public boolean m_271862_(Container p_273497_, int p_273168_, ItemStack p_273785_) {
      return p_273497_.m_216874_(ItemStack::m_41619_);
   }

   private void m_269320_(Level p_270782_, BlockPos p_270940_) {
      if (p_270782_ instanceof ServerLevel serverlevel) {
         Vec3 vec3 = Vec3.m_82539_(p_270940_).m_82520_(0.0D, (double)1.2F, 0.0D);
         float f = (float)p_270782_.m_213780_().m_188503_(4) / 24.0F;
         serverlevel.m_8767_(ParticleTypes.f_123758_, vec3.m_7096_(), vec3.m_7098_(), vec3.m_7094_(), 0, (double)f, 0.0D, 0.0D, 1.0D);
      }

   }

   public void m_272252_() {
      if (this.f_58857_ != null && !this.f_58857_.f_46443_) {
         BlockPos blockpos = this.m_58899_();
         ItemStack itemstack = this.m_272036_();
         if (!itemstack.m_41619_()) {
            this.m_272108_();
            Vec3 vec3 = Vec3.m_272021_(blockpos, 0.5D, 1.01D, 0.5D).m_272010_(this.f_58857_.f_46441_, 0.7F);
            ItemStack itemstack1 = itemstack.m_41777_();
            ItemEntity itementity = new ItemEntity(this.f_58857_, vec3.m_7096_(), vec3.m_7098_(), vec3.m_7094_(), itemstack1);
            itementity.m_32060_();
            this.f_58857_.m_7967_(itementity);
         }
      }
   }

   public static void m_239937_(Level p_239938_, BlockPos p_239939_, BlockState p_239940_, JukeboxBlockEntity p_239941_) {
      p_239941_.m_272276_(p_239938_, p_239939_, p_239940_);
   }

   @VisibleForTesting
   public void m_272139_(ItemStack p_272693_) {
      this.f_271436_.set(0, p_272693_);
      this.f_58857_.m_46672_(this.m_58899_(), this.m_58900_().m_60734_());
      this.m_6596_();
   }
}