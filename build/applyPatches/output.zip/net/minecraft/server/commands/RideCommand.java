package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

public class RideCommand {
   private static final DynamicCommandExceptionType f_263780_ = new DynamicCommandExceptionType((p_265076_) -> {
      return Component.m_237110_("commands.ride.not_riding", p_265076_);
   });
   private static final Dynamic2CommandExceptionType f_263682_ = new Dynamic2CommandExceptionType((p_265488_, p_265072_) -> {
      return Component.m_237110_("commands.ride.already_riding", p_265488_, p_265072_);
   });
   private static final Dynamic2CommandExceptionType f_263721_ = new Dynamic2CommandExceptionType((p_265321_, p_265603_) -> {
      return Component.m_237110_("commands.ride.mount.failure.generic", p_265321_, p_265603_);
   });
   private static final SimpleCommandExceptionType f_263778_ = new SimpleCommandExceptionType(Component.m_237115_("commands.ride.mount.failure.cant_ride_players"));
   private static final SimpleCommandExceptionType f_263832_ = new SimpleCommandExceptionType(Component.m_237115_("commands.ride.mount.failure.loop"));
   private static final SimpleCommandExceptionType f_268657_ = new SimpleCommandExceptionType(Component.m_237115_("commands.ride.mount.failure.wrong_dimension"));

   public static void m_264607_(CommandDispatcher<CommandSourceStack> p_265201_) {
      p_265201_.register(Commands.m_82127_("ride").requires((p_265326_) -> {
         return p_265326_.m_6761_(2);
      }).then(Commands.m_82129_("target", EntityArgument.m_91449_()).then(Commands.m_82127_("mount").then(Commands.m_82129_("vehicle", EntityArgument.m_91449_()).executes((p_265139_) -> {
         return m_264511_(p_265139_.getSource(), EntityArgument.m_91452_(p_265139_, "target"), EntityArgument.m_91452_(p_265139_, "vehicle"));
      }))).then(Commands.m_82127_("dismount").executes((p_265418_) -> {
         return m_264225_(p_265418_.getSource(), EntityArgument.m_91452_(p_265418_, "target"));
      }))));
   }

   private static int m_264511_(CommandSourceStack p_265285_, Entity p_265711_, Entity p_265339_) throws CommandSyntaxException {
      Entity entity = p_265711_.m_20202_();
      if (entity != null) {
         throw f_263682_.create(p_265711_.m_5446_(), entity.m_5446_());
      } else if (p_265339_.m_6095_() == EntityType.f_20532_) {
         throw f_263778_.create();
      } else if (p_265711_.m_20199_().anyMatch((p_265501_) -> {
         return p_265501_ == p_265339_;
      })) {
         throw f_263832_.create();
      } else if (p_265711_.m_9236_() != p_265339_.m_9236_()) {
         throw f_268657_.create();
      } else if (!p_265711_.m_7998_(p_265339_, true)) {
         throw f_263721_.create(p_265711_.m_5446_(), p_265339_.m_5446_());
      } else {
         p_265285_.m_81354_(Component.m_237110_("commands.ride.mount.success", p_265711_.m_5446_(), p_265339_.m_5446_()), true);
         return 1;
      }
   }

   private static int m_264225_(CommandSourceStack p_265724_, Entity p_265678_) throws CommandSyntaxException {
      Entity entity = p_265678_.m_20202_();
      if (entity == null) {
         throw f_263780_.create(p_265678_.m_5446_());
      } else {
         p_265678_.m_8127_();
         p_265724_.m_81354_(Component.m_237110_("commands.ride.dismount.success", p_265678_.m_5446_(), entity.m_5446_()), true);
         return 1;
      }
   }
}