package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.OutgoingChatMessage;
import net.minecraft.network.chat.PlayerChatMessage;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.PlayerList;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.scores.PlayerTeam;

public class TeamMsgCommand {
   private static final Style f_138996_ = Style.f_131099_.m_131144_(new HoverEvent(HoverEvent.Action.f_130831_, Component.m_237115_("chat.type.team.hover"))).m_131142_(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, "/teammsg "));
   private static final SimpleCommandExceptionType f_138997_ = new SimpleCommandExceptionType(Component.m_237115_("commands.teammsg.failed.noteam"));

   public static void m_138999_(CommandDispatcher<CommandSourceStack> p_139000_) {
      LiteralCommandNode<CommandSourceStack> literalcommandnode = p_139000_.register(Commands.m_82127_("teammsg").then(Commands.m_82129_("message", MessageArgument.m_96832_()).executes((p_248184_) -> {
         CommandSourceStack commandsourcestack = p_248184_.getSource();
         Entity entity = commandsourcestack.m_81374_();
         PlayerTeam playerteam = (PlayerTeam)entity.m_5647_();
         if (playerteam == null) {
            throw f_138997_.create();
         } else {
            List<ServerPlayer> list = commandsourcestack.m_81377_().m_6846_().m_11314_().stream().filter((p_272399_) -> {
               return p_272399_ == entity || p_272399_.m_5647_() == playerteam;
            }).toList();
            if (!list.isEmpty()) {
               MessageArgument.m_245478_(p_248184_, "message", (p_248180_) -> {
                  m_246910_(commandsourcestack, entity, playerteam, list, p_248180_);
               });
            }

            return list.size();
         }
      })));
      p_139000_.register(Commands.m_82127_("tm").redirect(literalcommandnode));
   }

   private static void m_246910_(CommandSourceStack p_248778_, Entity p_248891_, PlayerTeam p_250504_, List<ServerPlayer> p_249706_, PlayerChatMessage p_249707_) {
      Component component = p_250504_.m_83367_().m_130948_(f_138996_);
      ChatType.Bound chattype$bound = ChatType.m_241073_(ChatType.f_241694_, p_248778_).m_241018_(component);
      ChatType.Bound chattype$bound1 = ChatType.m_241073_(ChatType.f_241626_, p_248778_).m_241018_(component);
      OutgoingChatMessage outgoingchatmessage = OutgoingChatMessage.m_247282_(p_249707_);
      boolean flag = false;

      for(ServerPlayer serverplayer : p_249706_) {
         ChatType.Bound chattype$bound2 = serverplayer == p_248891_ ? chattype$bound1 : chattype$bound;
         boolean flag1 = p_248778_.m_243061_(serverplayer);
         serverplayer.m_245069_(outgoingchatmessage, flag1, chattype$bound2);
         flag |= flag1 && p_249707_.m_243059_();
      }

      if (flag) {
         p_248778_.m_243053_(PlayerList.f_243017_);
      }

   }
}