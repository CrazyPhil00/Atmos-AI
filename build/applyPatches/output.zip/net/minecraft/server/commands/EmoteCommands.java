package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.network.chat.ChatType;
import net.minecraft.server.players.PlayerList;

public class EmoteCommands {
   public static void m_136985_(CommandDispatcher<CommandSourceStack> p_136986_) {
      p_136986_.register(Commands.m_82127_("me").then(Commands.m_82129_("action", MessageArgument.m_96832_()).executes((p_248130_) -> {
         MessageArgument.m_245478_(p_248130_, "action", (p_248129_) -> {
            CommandSourceStack commandsourcestack = p_248130_.getSource();
            PlayerList playerlist = commandsourcestack.m_81377_().m_6846_();
            playerlist.m_243063_(p_248129_, commandsourcestack, ChatType.m_241073_(ChatType.f_237009_, commandsourcestack));
         });
         return 1;
      })));
   }
}