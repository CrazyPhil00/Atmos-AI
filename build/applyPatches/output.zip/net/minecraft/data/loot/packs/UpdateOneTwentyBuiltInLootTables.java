package net.minecraft.data.loot.packs;

import com.google.common.collect.Sets;
import java.util.Collections;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

public class UpdateOneTwentyBuiltInLootTables {
   private static final Set<ResourceLocation> f_271531_ = Sets.newHashSet();
   private static final Set<ResourceLocation> f_271521_ = Collections.unmodifiableSet(f_271531_);
   public static final ResourceLocation f_271249_ = m_272272_("archaeology/desert_well");
   public static final ResourceLocation f_271180_ = m_272272_("archaeology/desert_pyramid");

   private static ResourceLocation m_272272_(String p_272728_) {
      return m_271793_(new ResourceLocation(p_272728_));
   }

   private static ResourceLocation m_271793_(ResourceLocation p_273688_) {
      if (f_271531_.add(p_273688_)) {
         return p_273688_;
      } else {
         throw new IllegalArgumentException(p_273688_ + " is already a registered built-in loot table");
      }
   }

   public static Set<ResourceLocation> m_272188_() {
      return f_271521_;
   }
}