package net.minecraft.network.protocol.status;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;

public record ClientboundStatusResponsePacket(ServerStatus f_134886_) implements Packet<ClientStatusPacketListener> {
   public ClientboundStatusResponsePacket(FriendlyByteBuf p_179834_) {
      this(p_179834_.m_271872_(ServerStatus.f_271163_));
   }

   public void m_5779_(FriendlyByteBuf p_134899_) {
      p_134899_.m_272073_(ServerStatus.f_271163_, this.f_134886_);
   }

   public void m_5797_(ClientStatusPacketListener p_134896_) {
      p_134896_.m_6440_(this);
   }
}