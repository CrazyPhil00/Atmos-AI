package net.minecraft.world.flag;

public class FeatureFlagUniverse {
   private final String id;

   public FeatureFlagUniverse(String p_249484_) {
      this.id = p_249484_;
   }

   public String toString() {
      return this.id;
   }
}